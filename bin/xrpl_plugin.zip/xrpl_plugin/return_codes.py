import xrpl_plugin.rippled_py.return_codes as rippled_return_codes
from xrpl_plugin.rippled_py.return_codes import *

__doc__ = rippled_return_codes.__doc__

__all__ = list(rippled_return_codes.__dict__.keys())
